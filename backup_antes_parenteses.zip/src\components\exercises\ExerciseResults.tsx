import React from 'react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Award, Star, Trophy, BookOpen, CheckCircle, Zap } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import confetti from 'canvas-confetti';

interface ExerciseResultsProps {
  results: {
    totalExercises: number;
    correctAnswers: number;
    incorrectAnswers: number;
    accuracyPercentage: number;
    xpEarned: number;
    newLevel?: number;
    moduleCompleted: boolean;
  };
  onContinue: () => void;
  onLoginPrompt: () => void;
  isLoggedIn: boolean;
}

const ExerciseResults: React.FC<ExerciseResultsProps> = ({
  results,
  onContinue,
  onLoginPrompt,
  isLoggedIn
}) => {
  // Verificar se results existe para evitar erros
  if (!results) {
    return (
      <div className="max-w-md mx-auto">
        <Card className="border-t-4 border-t-brand-blue overflow-hidden">
          <CardHeader className="bg-brand-blue/5 pb-1">
            <div className="flex justify-between items-center">
              <CardTitle className="text-2xl font-bold">Resultados</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6">
            <p>Não foi possível carregar os resultados. Por favor, tente novamente.</p>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button onClick={onContinue}>Voltar</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }
  
  // Trigger confetti effect on component mount if module was completed
  React.useEffect(() => {
    if (results && results.moduleCompleted) {
      // Disparar evento para atualizar a barra de progresso na página Success
      const progressEvent = new Event('moduleProgressUpdated');
      window.dispatchEvent(progressEvent);
      
      // Efeito de confetti para celebrar
      const duration = 3 * 1000;
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 2,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ['#4285F4', '#0F9D58', '#F4B400', '#DB4437']
        });
        
        confetti({
          particleCount: 2,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ['#4285F4', '#0F9D58', '#F4B400', '#DB4437']
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };

      frame();
    }
  }, [results.moduleCompleted]);

  return (
    <div className="max-w-md mx-auto">
      <Card className="border-t-4 border-t-brand-blue overflow-hidden">
        <CardHeader className="bg-brand-blue/5 pb-1">
          <div className="flex justify-between items-center">
            <CardTitle className="text-2xl font-bold">
              {window.location.pathname.includes('/prova-virgula')
                ? (results && results.moduleCompleted 
                  ? 'Aprovado! 🎉' 
                  : 'Não Aprovado')
                : (results && results.moduleCompleted 
                  ? 'Exercício Concluído! 🎉' 
                  : 'Resultados')
              }
            </CardTitle>
          </div>
        </CardHeader>
        
        <CardContent className="pt-6">
          <div className="space-y-6">
            {/* Removido sistema de XP */}
            
            {/* Module completion status */}
            <div className={`border rounded-lg p-4 ${
              results && results.moduleCompleted 
                ? 'border-green-200 bg-green-50' 
                : 'border-orange-200 bg-orange-50'
            }`}>
              <div className="flex items-start">
                <div className={`rounded-full p-2 mr-3 ${
                  results && results.moduleCompleted 
                    ? 'bg-green-100 text-green-600' 
                    : 'bg-orange-100 text-orange-600'
                }`}>
                  {results && results.moduleCompleted 
                    ? <CheckCircle className="h-5 w-5" /> 
                    : <BookOpen className="h-5 w-5" />
                  }
                </div>
                <div>
                  <h3 className={`font-medium mb-1 ${
                    results && results.moduleCompleted 
                      ? 'text-green-800' 
                      : 'text-orange-800'
                  }`}>
                    {window.location.pathname.includes('/prova-virgula')
                      ? (results.moduleCompleted 
                        ? 'Você foi aprovado na Prova Final de Vírgula!' 
                        : 'Você não atingiu a pontuação mínima')
                      : (results.moduleCompleted 
                        ? 'Exercício concluído com sucesso!' 
                        : 'Exercício não concluído')
                    }
                  </h3>
                  <p className={`text-sm ${
                    results && results.moduleCompleted 
                      ? 'text-green-700' 
                      : 'text-orange-700'
                  }`}>
                    {window.location.pathname.includes('/prova-virgula')
                      ? (results && results.moduleCompleted 
                        ? 'Parabéns! Você acertou pelo menos 70% das questões.' 
                        : 'Você precisa acertar pelo menos 70% das questões para ser aprovado.')
                      : (results && results.moduleCompleted 
                        ? 'Seu progresso foi salvo. Continue para avançar na jornada.' 
                        : 'Você precisa acertar pelo menos 70% das questões para concluir o exercício com sucesso.')
                    }
                  </p>
                </div>
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-3 text-center">
              <div className="bg-gray-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-gray-800">{results && results.totalExercises || 0}</div>
                <div className="text-xs text-gray-600">Questões</div>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-green-600">{results && results.correctAnswers || 0}</div>
                <div className="text-xs text-gray-600">Corretas</div>
              </div>
              <div className="bg-red-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-red-500">{results && results.incorrectAnswers || 0}</div>
                <div className="text-xs text-gray-600">Incorretas</div>
              </div>
            </div>
            
            {/* Accuracy */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-sm font-medium">Precisão</span>
                <span className="text-sm font-medium">{results && results.accuracyPercentage || 0}%</span>
              </div>
              <Progress 
                value={results && results.accuracyPercentage || 0} 
                className={`h-2 ${results && results.accuracyPercentage < 50 
                    ? 'bg-red-100' 
                    : results && results.accuracyPercentage < 70 
                      ? 'bg-yellow-100' 
                      : 'bg-green-100'
                }`}
              />
              <div className="flex justify-between mt-1">
                <div className="flex items-center">
                  {[...Array(Math.floor((results && results.accuracyPercentage || 0) / 20))].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                  ))}
                  {[...Array(5 - Math.floor((results && results.accuracyPercentage || 0) / 20))].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-gray-300" />
                  ))}
                </div>
                <span className="text-xs text-gray-500">
                  {(results && results.accuracyPercentage || 0) >= 70 
                    ? 'Excelente!' 
                    : (results && results.accuracyPercentage || 0) >= 50 
                      ? 'Bom trabalho!' 
                      : 'Continue praticando!'}
                </span>
              </div>
            </div>
            
            {/* Login prompt for non-logged in users */}
            {!isLoggedIn && (
              <div className="border border-orange-200 bg-orange-50 p-4 rounded-lg">
                <h3 className="font-medium mb-2 text-orange-800">Quer salvar seu progresso?</h3>
                <p className="text-sm text-orange-700 mb-3">
                  Crie uma conta para acompanhar seu desempenho e desbloquear mais conteúdo!
                </p>
                <Button onClick={onLoginPrompt} size="sm" className="w-full">
                  Criar conta
                </Button>
              </div>
            )}
          </div>
        </CardContent>
        
        <CardFooter className="bg-gray-50 border-t">
          <Button onClick={onContinue} className="w-full">
            Continuar
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ExerciseResults;
