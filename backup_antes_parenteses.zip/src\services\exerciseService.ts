import { supabase } from '@/lib/supabase';
import { User } from '@supabase/supabase-js';
import { getDoisPontosExercises } from './doisPontosData';
import { getPontoEVirgulaExercises } from './pontoEVirgulaData';
import { getVirgulaExercises } from './virgulaData';

// Types
export interface Exercise {
  id: number;
  category_id: string;
  question: string;
  explanation: string;
  difficulty: number;
  options: ExerciseOption[];
}

export interface ExerciseOption {
  id: number;
  exercise_id: number;
  option_text: string;
  is_correct: boolean;
  explanation: string;
}

export interface ExerciseCategory {
  id: string;
  title: string;
  description: string;
}

export interface ExerciseResults {
  totalExercises: number;
  correctAnswers: number;
  incorrectAnswers: number;
  accuracyPercentage: number;
  xpEarned: number;
  newLevel?: number;
  moduleCompleted: boolean;
  completedExercises: Exercise[];
}

// Get exercises by category
export async function getExercisesByCategory(categoryId: string): Promise<Exercise[]> {
  // Para exercícios de Dois Pontos, usar os dados locais
  if (categoryId.includes('dois-pontos')) {
    console.log('Usando dados locais para exercícios de Dois Pontos:', categoryId);
    return getDoisPontosExercises(categoryId);
  }
  
  // Para exercícios de Ponto e Vírgula, usar os dados locais
  if (categoryId.includes('ponto-e-virgula')) {
    return getPontoEVirgulaExercises(categoryId);
  }
  
  // Para exercícios de Vírgula, usar os dados locais
  if (categoryId.includes('virgula')) {
    return getVirgulaExercises(categoryId);
  }
  
  // Caso nenhuma das condições acima seja atendida, retornar lista vazia
  // (todos os exercícios agora estão em arquivos locais)
  console.warn('Categoria não encontrada:', categoryId);
  return [];
}

// A função getUserProgressForCategory foi removida porque não precisamos mais rastrear o progresso individual por exercício
// Agora apenas rastreamos os módulos concluídos em profiles.completed_modules
export async function getUserModuleProgress(userId: string): Promise<Record<string, number>> {
  const { data, error } = await supabase
    .from('profiles')
    .select('completed_modules')
    .eq('id', userId)
    .single();

  if (error) {
    console.error('Error fetching user module progress:', error);
    return {};
  }

  return data?.completed_modules || {};
}

// Save user's answer to an exercise
export async function saveUserAnswer(
  user: User,
  exerciseId: number,
  isCorrect: boolean
): Promise<boolean> {
  // Get exercise to determine category (still needed)
  const { data: exercise, error: exerciseError } = await supabase
    .from('exercises')
    .select('category_id')
    .eq('id', exerciseId)
    .single();

  if (exerciseError) {
    console.error('Error fetching exercise category:', exerciseError);
    return false;
  }

  const categoryId = exercise.category_id;

  try {
    // Não é mais necessário salvar respostas individuais, apenas o módulo concluído
    // nas funções getExerciseResults quando o usuário completar um módulo

    // Retornar sucesso já que não estamos mais salvando progresso por exercício
    return true;
  } catch (error) {
    console.error('Error in saveUserAnswer:', error);
    return false;
  }
}

// Get exercise results for a session
export async function getExerciseResults(
  user: User, 
  categoryId: string, 
  completedExercises: Exercise[], 
  correctAnswers: number,
  moduleCompleted: boolean = false
): Promise<ExerciseResults> {
  const totalExercises = completedExercises.length;
  const incorrectAnswers = totalExercises - correctAnswers;
  const accuracyPercentage = totalExercises > 0 
    ? Math.round((correctAnswers / totalExercises) * 100) 
    : 0;
  
  // Calculate XP (10 per correct answer, 5 bonus for high accuracy)
  let xpEarned = correctAnswers * 10;
  if (accuracyPercentage >= 80) xpEarned += 5;
  if (accuracyPercentage === 100) xpEarned += 10;

  // Get user's previous stats to determine level progression
  const { data: userStats, error: statsError } = await supabase
    .from('profiles')
    .select('xp, level')
    .eq('id', user.id)
    .single();

  if (statsError) {
    console.error('Error fetching user stats:', statsError);
  }

  let newLevel = undefined;
  
  // Update user's XP and level in profiles table
  if (userStats) {
    const currentXp = userStats.xp || 0;
    const currentLevel = userStats.level || 1;
    const newXp = currentXp + xpEarned;
    
    // Simple level formula: level up every 100 XP
    const calculatedNewLevel = Math.floor(newXp / 100) + 1;
    
    if (calculatedNewLevel > currentLevel) {
      newLevel = calculatedNewLevel;
    }
    
    // Update profile with new XP and level
    const { error: updateError } = await supabase
      .from('profiles')
      .update({
        xp: newXp,
        level: calculatedNewLevel
      })
      .eq('id', user.id);
      
    if (updateError) {
      console.error('Error updating user XP and level:', updateError);
    }
  }

  // Update module progress if the session counts as a completed module
  if (moduleCompleted) {
    try {
      // Get the user's current module progress for this category
      const { data: moduleProgress, error: moduleProgressError } = await supabase
        .from('profiles')
        .select('completed_modules')
        .eq('id', user.id)
        .single();

      if (moduleProgressError) {
        console.error('Error fetching module progress:', moduleProgressError);
      } else {
        // The completed_modules field should be a JSON object with category IDs as keys 
        // and the number of completed modules as values
        const completedModules = moduleProgress?.completed_modules || {};
        
        // Increment the count for this category
        completedModules[categoryId] = (completedModules[categoryId] || 0) + 1;
        
        // Update the profile
        const { error: updateError } = await supabase
          .from('profiles')
          .update({
            completed_modules: completedModules
          })
          .eq('id', user.id);
          
        if (updateError) {
          console.error('Error updating module progress:', updateError);
        }
      }
    } catch (error) {
      console.error('Error processing module completion:', error);
    }
  }

  return {
    totalExercises,
    correctAnswers,
    incorrectAnswers,
    accuracyPercentage,
    xpEarned,
    newLevel,
    moduleCompleted,
    completedExercises
  };
}

// Get categories
export async function getCategories(): Promise<ExerciseCategory[]> {
  const { data, error } = await supabase
    .from('exercise_categories')
    .select('*')
    .order('id');

  if (error) {
    console.error('Error fetching categories:', error);
    return [];
  }

  return data || [];
}
