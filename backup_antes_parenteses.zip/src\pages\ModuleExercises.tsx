import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import StudyLayout from '@/components/StudyLayout';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, BookOpen, Award, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import ExerciseSession from '@/components/exercises/ExerciseSession';

const ModuleExercises: React.FC = () => {
  const { moduleId } = useParams<{ moduleId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [moduleTitle, setModuleTitle] = useState('Exercícios');
  const [moduleDescription, setModuleDescription] = useState('');
  const [loading, setLoading] = useState(true);
  const [completedModules, setCompletedModules] = useState(0);
  const [totalModules, setTotalModules] = useState(10); // Por padrão, cada tipo de pontuação tem 10 módulos

  useEffect(() => {
    // Map moduleId to title and description
    const moduleInfo: Record<string, {title: string, description: string}> = {
      'virgula': {
        title: 'Vírgula - Exercício 1',
        description: 'Introdução ao uso da vírgula na língua portuguesa.'
      },
      'virgula-2': {
        title: 'Vírgula - Exercício 2',
        description: 'Usos avançados da vírgula em estruturas coordenadas e termos explicativos.'
      },
      'virgula-3': {
        title: 'Vírgula - Exercício 3',
        description: 'Uso da vírgula para isolar o aposto e expressões explicativas.'
      },
      'virgula-4': {
        title: 'Vírgula - Exercício 4',
        description: 'Uso da vírgula em orações coordenadas e intercalações.'
      },
      'virgula-5': {
        title: 'Vírgula - Exercício 5',
        description: 'Casos especiais do uso da vírgula em diferentes contextos.'
      },
      'prova-virgula': {
        title: 'Prova Final de Vírgula',
        description: 'Avalie seu conhecimento sobre o uso da vírgula na língua portuguesa.'
      },
      // Módulos de Ponto e Vírgula
      'ponto-e-virgula': {
        title: 'Ponto e Vírgula - Exercício 1',
        description: 'Introdução ao uso do ponto e vírgula na língua portuguesa.'
      },
      'ponto-virgula-2': {
        title: 'Ponto e Vírgula - Exercício 2',
        description: 'Usos avançados do ponto e vírgula em estruturas coordenadas e termos explicativos.'
      },
      'ponto-virgula-3': {
        title: 'Ponto e Vírgula - Exercício 3',
        description: 'Uso do ponto e vírgula para separar orações coordenadas extensas.'
      },
      'ponto-virgula-4': {
        title: 'Ponto e Vírgula - Exercício 4',
        description: 'Uso do ponto e vírgula em enumerações complexas.'
      },
      'ponto-virgula-5': {
        title: 'Ponto e Vírgula - Exercício 5',
        description: 'Casos especiais do uso do ponto e vírgula em diferentes contextos.'
      },
      'prova-ponto-e-virgula': {
        title: 'Prova Final de Ponto e Vírgula',
        description: 'Avalie seu conhecimento sobre o uso do ponto e vírgula na língua portuguesa.'
      },
      // Módulos de Dois Pontos
      'dois-pontos': {
        title: 'Dois Pontos - Exercício 1',
        description: 'Introdução ao uso dos dois pontos na língua portuguesa.'
      },
      'dois-pontos-2': {
        title: 'Dois Pontos - Exercício 2',
        description: 'Uso dos dois pontos em enumerações e listagens.'
      },
      'dois-pontos-3': {
        title: 'Dois Pontos - Exercício 3',
        description: 'Dois pontos antes de citações e falas diretas.'
      },
      'dois-pontos-4': {
        title: 'Dois Pontos - Exercício 4',
        description: 'Dois pontos em explicações e esclarecimentos.'
      },
      'dois-pontos-5': {
        title: 'Dois Pontos - Exercício 5',
        description: 'Casos especiais do uso dos dois pontos em diversos contextos.'
      },
      'prova-dois-pontos': {
        title: 'Prova Final de Dois Pontos',
        description: 'Avalie seu conhecimento sobre o uso dos dois pontos na língua portuguesa.'
      }
    };
    
    if (moduleId && moduleInfo[moduleId]) {
      setModuleTitle(moduleInfo[moduleId].title);
      setModuleDescription(moduleInfo[moduleId].description);
      document.title = `${moduleInfo[moduleId].title} | Pontuação Mestre`;
      
      // Buscar progresso do usuário para este módulo
      fetchUserProgress();
    }
  }, [moduleId, user]);
  
  // Buscar o progresso do usuário para este módulo
  const fetchUserProgress = async () => {
    if (!user || !moduleId) {
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('completed_modules')
        .eq('id', user.id)
        .single();
      
      if (error) {
        console.error('Erro ao buscar progresso:', error);
      } else if (data) {
        // Módulos completados para esta categoria
        const categoryProgress = data.completed_modules[moduleId] || 0;
        setCompletedModules(categoryProgress);
      }
    } catch (err) {
      console.error('Erro ao processar progresso:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    navigate('/success');
  };

  return (
    <StudyLayout>
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            className="mb-2"
            onClick={handleBack}
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold mb-3">
            {moduleId && (moduleId.includes('ponto-e-virgula') || moduleId.includes('virgula') || moduleId.includes('dois-pontos')) ? (
              // Títulos para Ponto e Vírgula
              moduleId === 'ponto-e-virgula' ? 'Ponto e Vírgula - Exercício 1' :
              moduleId === 'ponto-e-virgula-2' ? 'Ponto e Vírgula - Exercício 2' :
              moduleId === 'ponto-e-virgula-3' ? 'Ponto e Vírgula - Exercício 3' :
              moduleId === 'ponto-e-virgula-4' ? 'Ponto e Vírgula - Exercício 4' :
              moduleId === 'ponto-e-virgula-5' ? 'Ponto e Vírgula - Exercício 5' :
              moduleId === 'prova-ponto-e-virgula' ? 'Prova Final de Ponto e Vírgula' :
              
              // Títulos para Vírgula
              moduleId === 'virgula' ? 'Vírgula - Exercício 1' :
              moduleId === 'virgula-2' ? 'Vírgula - Exercício 2' :
              moduleId === 'virgula-3' ? 'Vírgula - Exercício 3' :
              moduleId === 'virgula-4' ? 'Vírgula - Exercício 4' :
              moduleId === 'virgula-5' ? 'Vírgula - Exercício 5' :
              moduleId === 'prova-virgula' ? 'Prova Final de Vírgula' :
              
              // Títulos para Dois Pontos
              moduleId === 'dois-pontos' ? 'Dois Pontos - Exercício 1' :
              moduleId === 'dois-pontos-2' ? 'Dois Pontos - Exercício 2' :
              moduleId === 'dois-pontos-3' ? 'Dois Pontos - Exercício 3' :
              moduleId === 'dois-pontos-4' ? 'Dois Pontos - Exercício 4' :
              moduleId === 'dois-pontos-5' ? 'Dois Pontos - Exercício 5' :
              moduleId === 'prova-dois-pontos' ? 'Prova Final de Dois Pontos' :
              moduleTitle
            ) : moduleTitle}
          </h1>
          <p className="text-gray-600 mb-4">{moduleDescription}</p>

          <Card>
            <CardContent className="p-6">
              {moduleId ? (
                <ExerciseSession 
                  categoryId={moduleId}
                  maxExercises={moduleId === 'prova-dois-pontos' ? 30 : 10} 
                  moduleTitle={
                    moduleId === 'ponto-e-virgula' ? 'Ponto e Vírgula - Exercício 1' :
                    moduleId === 'ponto-e-virgula-2' ? 'Ponto e Vírgula - Exercício 2' :
                    moduleId === 'ponto-e-virgula-3' ? 'Ponto e Vírgula - Exercício 3' :
                    moduleId === 'ponto-e-virgula-4' ? 'Ponto e Vírgula - Exercício 4' :
                    moduleId === 'ponto-e-virgula-5' ? 'Ponto e Vírgula - Exercício 5' :
                    moduleId === 'prova-ponto-e-virgula' ? 'Prova Final de Ponto e Vírgula' :
                    moduleId === 'virgula' ? 'Vírgula - Exercício 1' :
                    moduleId === 'virgula-2' ? 'Vírgula - Exercício 2' :
                    moduleId === 'virgula-3' ? 'Vírgula - Exercício 3' :
                    moduleId === 'virgula-4' ? 'Vírgula - Exercício 4' :
                    moduleId === 'virgula-5' ? 'Vírgula - Exercício 5' :
                    moduleId === 'prova-virgula' ? 'Prova Final de Vírgula' :
                    moduleId === 'dois-pontos' ? 'Dois Pontos - Exercício 1' :
                    moduleId === 'dois-pontos-2' ? 'Dois Pontos - Exercício 2' :
                    moduleId === 'dois-pontos-3' ? 'Dois Pontos - Exercício 3' :
                    moduleId === 'dois-pontos-4' ? 'Dois Pontos - Exercício 4' :
                    moduleId === 'dois-pontos-5' ? 'Dois Pontos - Exercício 5' :
                    moduleId === 'prova-dois-pontos' ? 'Prova Final de Dois Pontos' :
                    moduleTitle
                  }
                />
              ) : (
                <div className="text-center py-8">
                  <p>Módulo não encontrado</p>
                  <Button 
                    onClick={handleBack}
                    className="mt-4"
                  >
                    Voltar para Módulos
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </StudyLayout>
  );
};

export default ModuleExercises;
